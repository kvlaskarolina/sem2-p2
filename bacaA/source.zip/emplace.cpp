//Karolina Kulas
//ok
#include "bitwise_operations.h"

void Emplace(char*l,int*z)
{
   *z=0;
    Insert(l,z);  
}