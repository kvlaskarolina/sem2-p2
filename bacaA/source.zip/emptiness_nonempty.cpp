//Karolina Kulas
bool Emptiness(int z)
{
    return !z;
}
bool Nonempty(int z)
{
    return z;
}